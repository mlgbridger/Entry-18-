const timedisplay = document.getElementById("timeDisplay");
const box1 = document.getElementById("box1");
const box2 = document.getElementById("box2");
const box3 = document.getElementById("box3");
const box4 = document.getElementById("box4");
const box5 = document.getElementById("box5");
const box6 = document.getElementById("box6");
const box7 = document.getElementById("box7");
const box8 = document.getElementById("box8");
const box9 = document.getElementById("box9");
const box10 = document.getElementById("box10");
const box11 = document.getElementById("box11");
const blackbox = document.getElementById("box12");
const winningallert = document.getElementById("winningallert");
const startButton = document.getElementById("startbutton");
const move = document.getElementById("movedisplay");
const time = document.getElementById("timer");
let moveCount = 0;

let numa = [box1, box2, box3, box4, box5, box6, box7, box8, box9, box10, box11, blackbox];

const winningOrder = [...numa];

let timerInterval = null;
let secondsElapsed = 0;
let isPlaying = false;

function updateBoard() {
    const rows = document.querySelectorAll(".miniboardingbox");
    numa.forEach((box, index) => {
        const rowIndex = Math.floor(index / 4);
        rows[rowIndex].appendChild(box);
    });
}

function shuffleBoard() {
    for (let i = 0; i < 150; i++) {
        let currentIndex = numa.indexOf(blackbox);
        let randomMove = Math.floor(Math.random() * 4);
        
        if (randomMove === 0 && currentIndex > 3) {
            [numa[currentIndex], numa[currentIndex - 4]] = [numa[currentIndex - 4], numa[currentIndex]];
        } else if (randomMove === 1 && currentIndex < 8) {
            [numa[currentIndex], numa[currentIndex + 4]] = [numa[currentIndex + 4], numa[currentIndex]];
        } else if (randomMove === 2 && currentIndex % 4 !== 0) {
            [numa[currentIndex], numa[currentIndex - 1]] = [numa[currentIndex - 1], numa[currentIndex]];
        } else if (randomMove === 3 && currentIndex % 4 !== 3) {
            [numa[currentIndex], numa[currentIndex + 1]] = [numa[currentIndex + 1], numa[currentIndex]];
        }
    }
    updateBoard();
}

function moveUp(arr, i1, i2) {
    if (i1 > 3) {
        [arr[i1], arr[i2]] = [arr[i2], arr[i1]];
        console.log(numa);
        moveCount++;
        updateBoard()
        checkWin();
    }
}
function moveDown(arr, i1, i2) {
    if (i1 < 8) {
        [arr[i1], arr[i2]] = [arr[i2], arr[i1]];
        console.log(numa);
        moveCount++;
        updateBoard()
        checkWin();
    }
}
function moveLeft(arr, i1, i2) {
    if (i1 % 4 !== 0) {
        [arr[i1], arr[i2]] = [arr[i2], arr[i1]];
        console.log(numa);
        moveCount++;
        updateBoard()
        checkWin();
    }
}
function moveRight(arr, i1, i2) {
    if (i1 % 4 !== 3) {
        [arr[i1], arr[i2]] = [arr[i2], arr[i1]];
        console.log(numa);
        moveCount++;
        updateBoard()
        checkWin();
    }
}
document.addEventListener("keydown", function(event) {
    let currentIndex = numa.indexOf(blackbox);
    if (isPlaying == false) {
        return;
    }
    if (event.key === "ArrowUp" || event.key === "w" || event.key === "W") {
        moveUp(numa, currentIndex, currentIndex - 4);
    }
    if (event.key === "ArrowDown" || event.key === "s" || event.key === "S") {
        moveDown(numa, currentIndex, currentIndex + 4);
    }
    if (event.key === "ArrowLeft" || event.key === "a" || event.key === "A") {
        moveLeft(numa, currentIndex, currentIndex - 1);
    }
    if (event.key === "ArrowRight" || event.key === "d" || event.key === "D") {
        moveRight(numa, currentIndex, currentIndex + 1);
    }
});
function formatTime(totalSeconds) {
    const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
    const seconds = (totalSeconds % 60).toString().padStart(2, "0");
    return `${minutes}:${seconds}`;
}

function checkWin() {
    let isWin = true;
    for (let i = 0; i < numa.length; i++) {
        if (numa[i] !== winningOrder[i]) {
            isWin = false;
            break;
        }
    }

    if (isWin && isPlaying && moveCount > 0) {
        clearInterval(timerInterval);
        isPlaying = false;
        winningallert.textContent = "YOU WIN!";
        move.textContent = `${moveCount}`;
        time.textContent = formatTime(secondsElapsed);
    }
}

function startGame() {
    if (timerInterval) clearInterval(timerInterval);
    
    secondsElapsed = 0;
    moveCount = 0;
    isPlaying = true;
    timeDisplay.textContent = "00:00";
    startButton.textContent = "Chơi lại";
    winningallert.textContent = "";
    shuffleBoard();

    timerInterval = setInterval(() => {
        secondsElapsed++;
        timeDisplay.textContent = formatTime(secondsElapsed);
    }, 1000);
}

startButton.addEventListener("click", startGame);