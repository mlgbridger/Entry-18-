let rightAnswer = document.getElementById("right");
let wrongAnswer1 = document.getElementById("wrong")[0];
let wrongAnswer2 = document.getElementById("wrong")[1];
let wrongAnswer3 = document.getElementById("wrong")[2];
let wrongAnswers = [wrongAnswer1, wrongAnswer2, wrongAnswer3];
let nextbutton = document.getElementById("disablenextbutton");
let scoredisplay = document.getElementById("score");
let rightAnswerClicked = 0;

rightAnswer.addEventListener("click", function() {
    rightAnswerClicked++;
    wrongAnswers.forEach(function(button) {
        button.id = "disableanswer";
    });
    rightAnswer.removeEventListener("click", arguments.callee);
    rightAnswer.id = "disablerightanswer";
    scoredisplay.textContent = `Điểm: ${rightAnswerClicked}`;
    nextbutton.id = "next-button";
    let nextbutton = document.getElementById("next-button");
    nextbutton.addEventListener("click", function() {
        
    })
});

wrongAnswers.forEach(function(button) {
    button.addEventListener("click", function() {
        wrongAnswers.forEach(function(button) {
            button.id = "disablewronganswer";
        });
        rightAnswer.removeEventListener("click", arguments.callee);
        wrongAnswers.forEach(function(button) {
            button.removeEventListener("click", arguments.callee);
        });
        rightAnswer.id = "disablerightanswer"
        scoredisplay.textContent = `Điểm: ${rightAnswerClicked}`;
        nextbutton.id = "next-button";
        let nextbutton = document.getElementById("next-button");
    });
});
